'use strict';

(function($) {
  $.extend($.fn.checkboxpicker.defaults, {
    offLabel: 'Pasif',
    onLabel: 'Aktif',
    warningMessage: 'Lütfen label elementi içerisinde Bootstrap-checkbox kullanmayınız.'
  });
})(jQuery);
