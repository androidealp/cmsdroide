<?php

namespace app\_adm;
use \Yii;


class Modules extends \yii\base\Module
{
    public $controllerNamespace = 'app\_adm\controllers';

    public function init()
    {
        parent::init();
        
         $this->defaultRoute = 'painel';
         
         Yii::$app->setComponents(
        [
            'errorHandler'=>[
                'errorAction'=>'_adm/painel/erro',
                'class'=>'yii\web\ErrorHandler',
            ],    
            'user' => [
                'class' => 'yii\web\User',
                'identityClass' => 'app\_adm\models\AdmUser',
                'loginUrl' => Yii::$app->urlManager->createUrl(['_adm/painel/login']),
            ],
        ]
    );
        
         
         
        

        // custom initialization code goes here
    }
}
