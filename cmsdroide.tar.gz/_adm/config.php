<?php
return [
    'components' => [
       
    ],
    'params' => [
        // list of parameters
    ],
];
