<?php
namespace app\components\helpers;
use \Yii;
/**
 * Controla o layout para admin e frontend
 */
class LayoutHelper {
   
   private $defaultTema = '';
   private static $Filedata = '';
   public static $urlBase = '@app/temas/';
    
    public function loadThemesJson(){   
        
        $dataFile =$this->renderFile(self::$urlBase.'themas.json');
        
        self::$Filedata = json_decode($dataFile, true);
        
        return new LayoutHelper;
    }
    
    
    /**
     * retorna o layout para front
     * @return string
     */
    public function front(){
        
        $pagesDetect = self::detectPages('frontend',self::$Filedata['frontend']);
        return  $pagesDetect;
    }
    
    /**
     * retorna o layout para admin
     * @return string
     */
    public function admin(){
        
        $pagesDetect = self::detectPages('admin',self::$Filedata['admin']);
        return  $pagesDetect;
    }
    
    /**
     * 
     * @param type $base // layout tipo admin / frontend
     * @param type $listpage // lista array onde do tipo selecionado
     * @return string // retorna a url layout.
     */
    public static function detectPages($base,$listpage){
        $defaultfolder  = $listpage['default']['tema'];
        $defaultfile    = $listpage['default']['layout'];
        $Theme = self::$urlBase.$base.'/'.$defaultfolder.'/'.$defaultfile;
        foreach ($listpage['pages'] as $k => $v) {
            if($k == \Yii::$app->controller->id && isset($v[\Yii::$app->controller->action->id])){
                $layout = $v[\Yii::$app->controller->action->id];
                $Theme = self::$urlBase.$base.'/'.$layout['tema'].'/'.$layout['layout'];
                
            }
        }
        
        return $Theme;
        
    }
    
}

