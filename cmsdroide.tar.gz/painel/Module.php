<?php

namespace app\painel;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\painel\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
