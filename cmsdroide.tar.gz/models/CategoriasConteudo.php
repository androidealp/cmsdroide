<?php

namespace app\models;

use Yii;

/**
 * This is the model class for table "csdm_categorias_conteudo".
 *
 * @property integer $id
 * @property integer $linguagem_id
 * @property string $nome
 * @property string $alias
 * @property string $dt_criacao
 * @property integer $status
 * @property string $parametros_extra
 *
 * @property CsdmLinguagem $linguagem
 * @property CsdmConteudo[] $csdmConteudos
 */
class CategoriasConteudo extends \yii\db\ActiveRecord
{
    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return 'csdm_categorias_conteudo';
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['linguagem_id', 'nome', 'alias', 'dt_criacao', 'status', 'parametros_extra'], 'required'],
            [['linguagem_id', 'status'], 'integer'],
            [['dt_criacao'], 'safe'],
            [['nome', 'alias', 'parametros_extra'], 'string', 'max' => 45]
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => 'ID',
            'linguagem_id' => 'Linguagem ID',
            'nome' => 'Nome',
            'alias' => 'Alias',
            'dt_criacao' => 'Dt Criacao',
            'status' => 'Status',
            'parametros_extra' => 'Parametros Extra',
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLinguagem()
    {
        return $this->hasOne(CsdmLinguagem::className(), ['id' => 'linguagem_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCsdmConteudos()
    {
        return $this->hasMany(CsdmConteudo::className(), ['categorias_conteudo_id' => 'id']);
    }
}
