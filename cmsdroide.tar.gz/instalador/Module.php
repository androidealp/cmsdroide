<?php

namespace app\instalador;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'app\instalador\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
